//main game logic

//importing game componenets
import {Player} from './src/game-objects/player.js';
import {GameObject, Entity, Item} from './src/game-objects/GameObject.js';
import {GameMap} from './src/game-world/map.js';
import {playerUpdate} from './src/game-objects/player-interaction.js';

export class Game {
  constructor(ctx) {
    this.ctx = ctx
    this.gravity = 5
    this.gameObjects = GameObject.gameObjects
    this.gameItems = GameObject.items
    this.player = new Player(180,30)
    this.gameMap = new GameMap()
    this.physicsWorker = new Worker('src/worker.js',{type:'module'})
    this.init()
  }
  
  init() {
    this.setupEventListeners()
    this.physicsWorker.onmessage = e => {
      
      this.handleWorkerUpdate(e)
    }
  }
  
  setupEventListeners() {
    window.addEventListener('keydown', e => {
      this.handleKeyDown(e)
    })
    window.addEventListener('keyup',e => {
      this.handleKeyUp(e)
    })
  }
  
  render(ctx) {
    ctx.clearRect(0,0,450,225)
    this.gameMap.renderBackground(ctx)
    this.player.render(ctx)
    this.gameItems.forEach((obj) => {
      obj.render(ctx)
    })
    
  }
  
  update() {
    this.gameMap.setMapData()
    this.player.setSprite()
    playerUpdate()
  }
  
  handleKeyDown(e) {
    this.player.isMoving = true
    switch (e.key) {
      case 'ArrowRight':
        this.player.direction = 'right'
        this.player.state = 'moving'
        this.player.vx = 5
        break;
      case 'ArrowLeft':
        this.player.direction = 'left'
        this.player.state = 'moving'
        this.player.vx = -5
        break;
      case 'ArrowUp':
        this.player.state = 'jumping'
        this.player.isJumping = true
        //this.player.y += this.player.upthrust
        break;
      case 'n':
        if (this.player.canPick && this.player.itemInRange) {
          this.player.inventory.addPrimaryItem(this.player.itemInRange)
          this.player.canPick = false
        }
        break;
      case 'c':
        this.player.inventory.clearInventory()
        break;
      case 's':
        this.player.inventory.switchItems()
        break;
      case 'q':
        new Item('py',90,140)
        break;
      
    }
    this.player.updateDisplacement()
  }
  
  handleKeyUp(e) {
    this.player.isMoving = false
    this.player.state = 'idle'
  }
  
  updateWorker(worker) {
    //simple motion
    let gameObjectData = this.gameObjects.map((obj) => (obj.getData()))
    
    worker.postMessage({
      gameObjects:gameObjectData,
      gravity:this.gravity,
      mapData:GameMap.levelProps
    })
  }
  
  handleWorkerUpdate(e) {
    let info = e.data
    
    info.updatedGameObjects.forEach((data,index) => {
      const existingGameObjects = this.gameObjects[index]//GameObject.gameObjects[index]
      
      if (existingGameObjects) {
        existingGameObjects.x = data.x
        existingGameObjects.y = data.y
        existingGameObjects.vx = data.vx
        existingGameObjects.vy = data.vy
        existingGameObjects.ax = data.ax
        existingGameObjects.isMoving = data.isMoving
        existingGameObjects.onGround = data.onGround
        existingGameObjects.isJumping = data.isJumping
      }
    })
  }
  
}