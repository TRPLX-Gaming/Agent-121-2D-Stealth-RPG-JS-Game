//game loop

//import game logic
import {Game} from './game.js';

//init dom
const canvas = document.querySelector('.canvas')
const cx = canvas.getContext('2d')
cx.imageSmoothingEnabled = false
const playerIdle = document.querySelector('.p-idle')
const playerRightMove = document.querySelector('.p-right')
const playerLeftMove = document.querySelector('.p-left')
const inventorySlot1 = document.querySelector('.slot1')
const primaryPlayerItem = inventorySlot1.querySelector('.item')
const inventorySlot2 = document.querySelector('.slot2')
const secondaryPlayerItem = inventorySlot2.querySelector('.item')

//player sprites
export let playerSprites = {
  playerIdle,
  playerLeftMove,
  playerRightMove
}

//main game loop
let game = new Game(cx)
const FPS = 60
const frameTime = 1000/FPS
let lastTime = 0
function gameLoop(timestamp) {
  let deltaTime = timestamp - lastTime
  if (deltaTime >= frameTime) {
    lastTime = timestamp
    //cx.clearRect(0,0,canvas.width,canvas.height)
    //game loop logic
    game.update()
    updatePlayerInventory()
    game.render(cx)
    game.updateWorker(game.physicsWorker)
  }
  requestAnimationFrame(gameLoop)
}
requestAnimationFrame(gameLoop)

function updatePlayerInventory() {
  primaryPlayerItem.textContent = game.player.inventory.getPrimaryItem()
  secondaryPlayerItem.textContent = game.player.inventory.getSecondaryItem()
}