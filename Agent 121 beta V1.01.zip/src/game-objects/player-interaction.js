//for checking player interactions with other game objs, tried using web workers and im telling you that that was what ate a whole week of my time
//getting game objs
import {GameObject} from './GameObject.js';
//utils
import {rectCollision as collides} from './../utils/collision-library.js';

//for player-item interaction
function itemInteraction() {
  GameObject.items.forEach((item) => {
    GameObject.gameObjects.forEach((obj) => {
      if (obj.id === 'player') {
        if (collides(obj,item)) {
          obj.canPick = true
          obj.itemInRange = item
        } else {
          obj.canPick = false
          obj.itemInRange = null
        }
      }
    })
  })
}

export function playerUpdate() {
  itemInteraction()
}