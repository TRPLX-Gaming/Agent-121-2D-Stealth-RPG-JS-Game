//import functionality
//base class
import {Entity} from './GameObject.js';
//import sprites
import {playerSprites} from './../../main.js';
//as a 10x we must try to overcomplicate things so ppl wont understand our ways hehehehehehe
//so to get the tilesize we must import it manually
/*
import {GameMap} from './../game-world/map.js';
const tilesize = new GameMap().tilesize
*/
//but later changed my minddue to performance on this terrible language
const tilesize = 25

//using custom sprite animation library
//not yet ready 

//using custom inventory system
import {DoubleInventory} from './../utils/inventory-system.js';

export class Player extends Entity {
  constructor(x,y) {
    super(x,y)
    this.id = 'player'
    this.style = 'red'
    this.sprite = null
    this.frames = 3
    this.frameX = 0
    this.frameY = 0
    this.lag = 0
    this.delay = 5
    this.canPick = false
    this.itemInRange = null
    this.inventory = new DoubleInventory()
    this.setSprite()
  }
  
  setSprite() {
    
    switch (this.state) {
      case 'idle':
        this.sprite = playerSprites.playerIdle
        break;
      case 'moving':
        this.sprite = this.direction === 'right' ? playerSprites.playerRightMove : this.direction === 'left' ? playerSprites.playerLeftMove : null
        break;
      case 'jumping':
        this.sprite = playerSprites.playerIdle
        break;
      
    }
    this.frames = this.sprite.width/tilesize
  }
  
  //dont forget to create a sprite animation library to flex 10x skills
  //tell sijibomi that he is doing well by creating his own libraries
  //im tired asf rn
  render(ctx) {
    
    ctx.drawImage(
      this.sprite,
      this.frameX * tilesize,
      this.frameY,
      this.width,
      this.height,
      this.x,
      this.y,
      tilesize,
      tilesize,
    )
    
    this.lag++
    
    if (this.lag >= this.delay) {
      this.frameX = (this.frameX + 1) % this.frames
      this.lag = 0
    }
    
  }
  
  updateDisplacement() {
    //this.vx = this.direction === 'right' ? 5 : this.direction === 'left' ? -5 : 0
    this.ax = this.vx !== 0 ? (this.vx/4) : 0
  }
  
}