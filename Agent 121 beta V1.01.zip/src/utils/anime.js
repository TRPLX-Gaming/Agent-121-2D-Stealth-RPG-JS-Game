export class Animator {
  constructor(sprite) {
    this.sprite = sprite
    this.frames = 0
    this.frameX = 0
    this.frameY = 0
    this.tilesize = 25
    this.lag = 0
    this.delay = 0
    this.spriteImageData = {}
  }
  
  getFrames() {return this.sprite.width/this.tilesize}
  
  getSprite() {return this.sprite}
  
  draw(ctx,x,y) {
    ctx.drawImage(
     this.sprite,
     this.frameX * this.tilesize,
     this.frameY,
     this.tilesize,
     this.tilesize,
     x,
     y,
     this.tilesize,
     this.tilesize,
   )

   this.lag++

   if (this.lag >= this.delay) {
      this.frameX = (this.frameX + 1) % this.frames
      this.lag = 0
    }
  }
  
}