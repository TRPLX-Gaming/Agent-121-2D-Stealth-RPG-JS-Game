//getting game obj class for removed items
import {GameObject} from './../game-objects/GameObject.js';

//simple inventory system with 2 slots made for the game
export class DoubleInventory {
  constructor(item1=null,item2=null) {
    this.inventory = {
      slot1:item1,
      slot2:item2
    }
    this.primaryItem = this.inventory.slot1
    this.secondaryItem = this.inventory.slot2
  }
  
  addPrimaryItem(item) {
    GameObject.items.shift(item)
    this.removeItem(this.primaryItem)
    this.primaryItem = item
  }
  
  addSecondaryItem(item) {
    this.removeItem(this.secondaryItem)
    this.secondaryItem = item
  }
  
  getPrimaryItem() {return this.primaryItem?.name ?? 'empty'}
  getSecondaryItem() {return this.secondaryItem?.name ?? 'empty'}
  
  removeItem(slot) {
    if (slot !== null) {
      //GameObject.gameObjects.push(slot)
      slot = null
    }
  }
  
  clearInventory() {
    this.removeItem(this.primaryItem)
    this.primaryItem = null
    this.removeItem(this.secondaryItem)
    this.secondaryItem = null
  }
  
  switchItems() {
    let hold = this.primaryItem
    this.primaryItem = this.secondaryItem
    this.secondaryItem = hold
  }
  
}

//to be worked on later
export class DynamicInventory {
  constructor(size) {
    
  }
}