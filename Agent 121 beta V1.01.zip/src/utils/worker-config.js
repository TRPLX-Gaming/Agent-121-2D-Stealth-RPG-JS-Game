//most of my games have 25x25
//const tilesize = 25

import {rectCollision as collides} from './collision-library.js';

import {GameMap} from '../game-world/map.js';
const tilesize = new GameMap().tilesize

export function getTile(mapData,tileData) {
  let tiles = []
  for(let y=0;y<mapData.length;y++) {
    for(let x=0;x<mapData[y].length;x++) {
      const tile = mapData[y][x]
      let tileX = x * tilesize
      let tileY = y * tilesize
      if (tile === tileData) {
        tiles.push({
          x: tileX,
          y: tileY,
          width: tilesize,
          height: tilesize
        })
      }
    }
  }
  return tiles
}

export function applyGravity(obj,gravity) {
  if (!obj.onGround) {
    obj.vy += gravity
    obj.y += obj.vy
  }
}

export function applyMotion(obj) {
  if (obj.isMoving) {
    obj.x += obj.vx
    obj.vx += obj.ax
  } else {
    obj.vx = 0
    obj.ax = 0
  }
}

export function checkPlatformCollision(platforms,obj) {
  if (obj.vy > 0) {
    platforms.forEach((land) => {
      if (collides(obj,land)) {
        obj.onGround = true
        obj.vy = 0
        obj.y = land.y - obj.height
      } else obj.onGround = false
    })
  }
}

export function checkWallCollision(walls,obj) {
  walls.forEach((wall) => {
    if (collides(obj,wall)) {
      
      obj.vx = obj.direction === 'right' ? (obj.vx - (wall.width/4)) : obj.direction === 'left' ? (obj.x + (wall.width/4)) : 0
    }
  })
}

export function jump(obj) {
  if (obj.isJumping) {
    obj.y += obj.upthrust
    obj.vy = 0
    obj.onGround = false
    obj.isJumping = false
  }
}