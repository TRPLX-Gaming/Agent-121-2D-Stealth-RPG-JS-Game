//using custom libraries
import {getTile, applyGravity, applyMotion, checkPlatformCollision, checkWallCollision, jump} from './utils/worker-config.js';
//because im a 10x dev i will get the tilesize by manually importing the world map file


onmessage = e => {
  let info = e.data
  
  let {gameObjects,gravity,mapData} = info
  
  let platforms = getTile(mapData,1)
  
  let walls = getTile(mapData,2)
  
  let result = updatePhysics(gameObjects, gravity, platforms, walls)
  
  postMessage({
    updatedGameObjects:result
  })
}

function updatePhysics(objects, gravity, platforms, walls) {
  objects.forEach((obj) => {
    
    applyMotion(obj)
    
    applyGravity(obj,gravity)
    
    jump(obj)
    
    checkPlatformCollision(platforms,obj)
    
    checkWallCollision(walls,obj)
  })
  return objects
}
