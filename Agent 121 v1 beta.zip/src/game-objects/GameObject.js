//import utilities


export class GameObject {
  constructor(x,y) {
    this.id = ''
    this.x = x
    this.y = y
    this.vx = 0
    this.vy = 0
    this.ax = 0
    this.ay = 0
    this.width = 25
    this.height = 25
    this.style = 'blue'
    GameObject.gameObjects.push(this)
  }
  
  static gameObjects = []
  static entities = []
  static items = []
  static medkits = []
  static weapons = []
  static crates = []
  static enemies = []
  static bullets = []
  
  render(ctx) {
    ctx.fillStyle = this.style
    ctx.fillRect(this.x,this.y,this.width,this.height)
  }
  
  getData() {
    return({
      x:this.x,
      y:this.y,
      vx:this.vx,
      vy:this.vy,
      ax:this.ax,
      ay:this.ay,
      width:this.width,
      height:this.height
    })
  }
  
}

//entity class
export class Entity extends GameObject {
  constructor(x,y) {
    super(x,y)
    this.id = 'entity'
    this.state = 'idle'
    this.health = 100
    this.isMoving = false
    this.isJumping = false
    this.upthrust = -40
    this.direction = 'right'
    this.onGround = false
    GameObject.entities.push(this)
  }
  
  getData() {
    return({
      ...super.getData(),
      isMoving:this.isMoving,
      onGround:this.onGround,
      isJumping:this.isJumping,
      upthrust:this.upthrust,
    })
  }
  
}

//item objects
export class Item extends GameObject {
  constructor(x,y) {
    super(x,y)
    this.id = 'item'
    GameObject.items.push(this)
  }
}
//subclasses of items
class Consumable extends Item {
  constructor(x,y) {
   super(x,y)
  }
}

class Medkit extends Consumable {
  constructor(x,y) {
    super(x,y)
    GameObject.medkits.push(this)
  }
}

class Crate extends Consumable {
  constructor(x,y) {
    super(x,y)
    GameObject.crates.push(this)
  }
}

//weapon subclass
class Weapon extends Item {
  constructor(x,y) {
    super(x,y)
    GameObject.weapons.push(this)
  }
}

//projectiles
class Bullet extends Item {
  constructor(x,y) {
    super(x,y)
    GameObject.bullets.push(this)
  }
}
