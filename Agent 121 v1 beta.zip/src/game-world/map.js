//import map data
import {BG} from '././map-data.js';

export class GameMap {
  constructor() {
    this.tilesize = 25
  }
  
  tileX
  tileY
  tileWidth
  tileHeight
  static level = 1
  static levelData
  static levelProps
  
  setMapData() {
    if (GameMap.level === 1) {
      GameMap.levelData = BG.demo
      GameMap.levelProps = BG.demo
    } else {
      GameMap.levelData = BG.street
      GameMap.levelProps = BG.street
    }
  }
  
  getTile(value,ctx) {
    switch (value) {
      case 0:
        ctx.fillStyle = 'khaki'
        break;
      case 1:
        ctx.fillStyle = 'navy'
        break;
      case 2:
        ctx.fillStyle = 'maroon'
        break;
      
    }
  }
  
  renderBackground(ctx) {
    for(let row=0;row<GameMap.levelData.length;row++) {
      for(let col=0;col<GameMap.levelData[row].length;col++) {
        let tile = GameMap.levelData[row][col]
        this.tileX = col * this.tilesize
        this.tileY = row * this.tilesize
        this.getTile(tile,ctx)
        ctx.fillRect(this.tileX,this.tileY,this.tilesize,this.tilesize)
      }
    }
  }
  
}