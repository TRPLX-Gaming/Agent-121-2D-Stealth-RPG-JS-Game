export function rectCollision(a, b) {
  return ((a.x + a.width) > b.x && (b.x + b.width) > a.x && (a.y + a.height) > b.y && (b.y + b.height) > a.y)
}

export function circleCollision(a,b) {
  let dX = a.x - b.x, dY = a.y - b.y, distance = Math.hypot(dX,dY)
  return (distance <= (a.radius + b.radius))
}